<div>
    <?php if($holiday): ?>
    <div class="alert alert-success">
        <small class="fw-bold">Hari ini adalah hari libur.</small>
    </div>
    <?php else: ?>

    
    <?php if($attendance->data->is_using_qrcode && !$data['is_there_permission']): ?>

    
    <?php if($attendance->data->is_start && !$data['is_has_enter_today']): ?>
    <button class="btn btn-primary px-3 py-2 btn-sm fw-bold d-block w-100 mb-2" data-bs-toggle="modal"
        data-bs-target="#qrcode-scanner-modal" data-is-enter="1">Scan QRCode Masuk</button>
    <a href="<?php echo e(route('home.permission', $attendance->id)); ?>"
        class="btn btn-info px-3 py-2 btn-sm fw-bold d-block w-100">Izin</a>
    <?php endif; ?>

    <?php if($data['is_has_enter_today']): ?>
    <div class="alert alert-success">
        <small class="d-block fw-bold text-success">Anda sudah berhasil mengirim absensi masuk.</small>
    </div>
    <?php endif; ?>

    
    <?php if($attendance->data->is_end && $data['is_has_enter_today'] && $data['is_not_out_yet']): ?>
    <button class="btn btn-primary px-3 py-2 btn-sm fw-bold d-block w-100" data-bs-toggle="modal"
        data-bs-target="#qrcode-scanner-modal" data-is-enter="0">Scan QRCode Pulang</button>
    <?php endif; ?>

    
    <?php if($data['is_has_enter_today'] && !$data['is_not_out_yet']): ?>
    <div class="alert alert-success">
        <small class="d-block fw-bold text-success">Anda sudah melakukan absen masuk dan absen
            pulang.</small>
    </div>
    <?php endif; ?>

    
    <?php if($data['is_has_enter_today'] && !$attendance->data->is_end): ?>
    <div class="alert alert-danger">
        <small class="fw-bold">Belum saatnya melakukan absensi pulang.</small>
    </div>
    <?php endif; ?>
    <?php endif; ?>

    <?php if($data['is_there_permission'] && !$data['is_permission_accepted']): ?>
    <div class="alert alert-info">
        <small class="fw-bold">Permintaan izin sedang diproses (atau masih belum di terima).</small>
    </div>
    <?php endif; ?>

    <?php if($data['is_there_permission'] && $data['is_permission_accepted']): ?>
    <div class="alert alert-success">
        <small class="fw-bold">Permintaan izin sudah diterima.</small>
    </div>
    <?php endif; ?>

    <?php endif; ?>

    <div class="modal fade" id="qrcode-scanner-modal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Scan QRCode Absensi</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="reader"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('html5-qrcode/html5-qrcode.min.js')); ?>"></script>
<script>
    const enterPresenceUrl = "<?php echo e(route('home.sendEnterPresenceUsingQRCode')); ?>";
    const outPresenceUrl = "<?php echo e(route('home.sendOutPresenceUsingQRCode')); ?>";
</script>
<script type="module" src="<?php echo e(asset('js/home/qrcode.js')); ?>"></script>
<?php $__env->stopPush(); ?><?php /**PATH /Users/notandz/Downloads/absensi-app/resources/views/home/partials/qrcode-presence.blade.php ENDPATH**/ ?>