<?php $__env->startSection('buttons'); ?>
<div class="btn-toolbar mb-2 mb-md-0">
    <div>
        <a href="<?php echo e(route('employees.index')); ?>" class="btn btn-sm btn-light">
            <span data-feather="arrow-left-circle" class="align-text-bottom"></span>
            Kembali
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-7">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('employee-edit-form', ['employees' => $employees])->html();
} elseif ($_instance->childHasBeenRendered('2TlNxur')) {
    $componentId = $_instance->getRenderedChildComponentId('2TlNxur');
    $componentTag = $_instance->getRenderedChildComponentTagName('2TlNxur');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2TlNxur');
} else {
    $response = \Livewire\Livewire::mount('employee-edit-form', ['employees' => $employees]);
    $html = $response->html();
    $_instance->logRenderedChild('2TlNxur', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/notandz/absensi-app/resources/views/employees/edit.blade.php ENDPATH**/ ?>