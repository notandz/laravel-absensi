@extends('layouts.base')

@section('base')

@include('partials.home-navbar')

@yield('content')

@endsection